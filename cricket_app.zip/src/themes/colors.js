export default {
    white: '#ffffff',
    black: '#131314',
    grey: '#d7dfe3',
    green: '#27ae60',
    orange: '#f39c12',
    blue: '#2980b9',
    red: '#ef1f28',
    yellow: '#f5c94e',
    purple: '#933da8',
    salmon: '#fc714e',
    gray: '#848b90',
    dark: '#4d4d4d',
};
