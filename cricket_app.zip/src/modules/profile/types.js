export default {
    SET_PROFILE: 'SET_PROFILE',
};
