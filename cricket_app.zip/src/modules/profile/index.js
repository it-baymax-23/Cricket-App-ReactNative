import profileReducer from './reducers';

export {default as profileActionTypes} from './types';
export {default as profileActions} from './actions';

export default profileReducer;
