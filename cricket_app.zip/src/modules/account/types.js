export default {
    SET_ACCOUNT: 'SET_ACCOUNT',
};
