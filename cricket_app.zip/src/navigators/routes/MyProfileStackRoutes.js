import {MyProfileScreen} from '../../screens';

const MyProfileStackRoutes = {
    MyProfileScreen: {
        screen: MyProfileScreen,
        navigationOptions: {
            header: null,
        },
    },
};

export default MyProfileStackRoutes;
